# querypie

![Version: 1.2.0](https://img.shields.io/badge/Version-1.2.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 9.20.0](https://img.shields.io/badge/AppVersion-9.20.0-informational?style=flat-square)

A Helm chart for QueryPie

**Homepage:** <https://www.querypie.com/>

## Requirements

Kubernetes: `^1.25.0-0`

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| appVersion | string | `"9.20.0"` |  |
| config.agentless.enableProxyProtocolv2 | bool | `false` | If true, QueryPie will expect to receive the Proxy Protocol v2 header. |
| config.agentless.enabled | bool | `false` | If true, QueryPie will enable the Agentless connection. This will open {startPort}~{endPort}/tcp ports on proxyService LoadBalancer. Be careful when you enable this feature because the LoadBalancer may not support a large number of ports to be opened. |
| config.agentless.endPort | int | `40000` |  |
| config.agentless.startPort | int | `40000` |  |
| config.cloudsync.aws.accountID | string | `"983146707838"` | The Account ID of the AWS used for cross-account access. |
| config.cloudsync.aws.enabled | bool | `false` | If true, QueryPie will automatically sync resources in the AWS. |
| config.database.querypie.connectionPoolSize | int | `20` | The maximum number of connections that QueryPie can use for "metastore" purposes. |
| config.externalURL | string | `"https://querypie.querypie.io"` | External URL that users use to access the QueryPie via web. Specify the scheme, hostname, and port is required. |
| config.secretName | string | `"querypie-secret"` | The secret used for the general QueryPie config. To create, run `kubectl create secret generic querypie-secret --from-env-file=querypie.env` The secret should contain the following ``` AGENT_SECRET: {32 length string} DB_HOST: querypie-db.querypie.com DB_PORT: 3306 DB_USERNAME: querypie DB_PASSWORD: somepassword DB_CATALOG: querypie LOG_DB_HOST: querypie-db.querypie.com LOG_DB_PORT: 3306 LOG_DB_USERNAME: querypie LOG_DB_PASSWORD: somepassword LOG_DB_CATALOG: querypie-log ENG_DB_HOST: querypie-db.querypie.com ENG_DB_PORT: 3306 ENG_DB_USERNAME: querypie ENG_DB_PASSWORD: somepassword ENG_DB_CATALOG: querypie-snapshot REDIS_DB: 0 REDIS_HOST: querypie-redis.querypie.com REDIS_PORT: 6379 REDIS_PASSWORD: somepassword ``` |
| config.sqlJob.enabled | bool | `false` | If true, QueryPie will enable the SQL Job feature. All SQL Jobs will be executed on the `querypie-0` pod. |
| config.syslog.enabled | bool | `false` | If true, QueryPie will send logs to the syslog server. Deprecated since QueryPie 9.19.0 |
| config.syslog.host | string | `"syslog.querypie.io"` | The host of the syslog server. Deprecated since QueryPie 9.19.0 |
| config.syslog.port | int | `514` | The port of the syslog server. Deprecated since QueryPie 9.19.0 |
| config.syslog.timezone | string | `"UTC"` | The timezone that will be used for the syslog messages. It should be a valid timezone string such as "Asia/Seoul", "Asia/Tokyo", "UTC", and so on. Deprecated since QueryPie 9.19.0 |
| global.image.pullPolicy | string | `"IfNotPresent"` | Default image pull policy for all images |
| global.image.registry | string | `"harbor.chequer.io"` | Default registry used for all images |
| global.image.tag | string | `"9.20.0"` | Default image tags used for all images |
| global.labels | object | `{}` | Default labels for all resources deployed by the chart |
| querypie.annotations | object | `{}` | Annotations used for QueryPie pods. |
| querypie.appService | object | `{"annotations":{},"labels":{}}` | The service used for the QueryPie pods' 80/tcp port. |
| querypie.appService.annotations | object | `{}` | Annotations used for the app service resource. |
| querypie.appService.labels | object | `{}` | Labels used for the app service resource. |
| querypie.extraEnvs | object | `{}` | Extra environment variables used for the QueryPie pods. This is useful for experimental features, debugging, workaround, and so on. for example: API_JVM_HEAPSIZE: '2g' will set the JVM heap size to 2GB. |
| querypie.image.pullPolicy | string | `nil` | PullPolicy used for the QueryPie image. If not set, the global pullPolicy will be used. |
| querypie.image.registry | string | `nil` | Registry used for the QueryPie image. If not set, the global registry will be used. |
| querypie.image.repository | string | `"querypie/querypie"` | Repository used for the QueryPie image. (required) |
| querypie.image.tag | string | `nil` | Tag used for the QueryPie image. If not set, the global tag will be used. |
| querypie.ingress.annotations | object | `{}` | Annotations used for the Ingress resource. It is useful when you want to enable controller-specific feature for the Ingress resource. |
| querypie.ingress.enabled | bool | `true` | If true, Ingress resource for QueryPie will be created. |
| querypie.ingress.extraPaths | list | `[]` | Extra paths used for the Ingress resource. It is mostly used for redirecting HTTP to HTTPS if the ingress controller does not support redirect by default. |
| querypie.ingress.host | string | `"querypie.querypie.io"` | Hostname used for the Ingress resource. If not set, every hostname will be accepted. |
| querypie.ingress.ingressClassName | string | `""` | Class used for the Ingress resource. If not set, the default class will be used. |
| querypie.ingress.labels | object | `{}` |  |
| querypie.ingress.tls | list | `[]` | TLS used for the Ingress resource. |
| querypie.labels | object | `{}` | Labels used for QueryPie pods. |
| querypie.logrotator.annotations | object | `{}` |  |
| querypie.logrotator.enabled | bool | `true` | If true, the logrotate will be deployed to rotate the logs in /var/log/querypie. |
| querypie.logrotator.image.repository | string | `"querypie/logrotate"` | Repository used for the Logrotate image. (required) |
| querypie.logrotator.image.tag | string | `"latest"` | Tag used for the Logrotate image. If not set, the global tag will be used. |
| querypie.logrotator.labels | object | `{}` |  |
| querypie.logrotator.resoruces | object | `{}` |  |
| querypie.nodeSelector | object | `{}` | NodeSelector for QueryPie pods |
| querypie.podManagementPolicy | string | `"Parallel"` | PodManagementPolicy for QueryPie pods. OrderedReady is fine for most cases, but Parallel is also good for large-scale deployments. |
| querypie.proxyService.annotations | object | `{}` | Annotations used for the Service resource. It is useful when you want to enable controller-specific feature for the Service resource. |
| querypie.proxyService.enabled | bool | `true` | Create a service resource for QueryPie Agent connections. Basically, it opens 9000/tcp port for the QueryPie Agent, and 40000~/tcp for the Agentless connections. |
| querypie.proxyService.externalTrafficPolicy | string | `"Local"` | Set the externalTrafficPolicy to Local is recommended for auditing the real client IP address. |
| querypie.proxyService.labels | object | `{}` |  |
| querypie.proxyService.loadBalancerClass | string | `""` |  |
| querypie.proxyService.sessionAffinity | string | `"None"` | SessionAffinity is not required for the QueryPie. |
| querypie.proxyService.type | string | `"LoadBalancer"` |  |
| querypie.replicas | int | `1` | Replica count for QueryPie pods. More than 1 is recommended for high availability. |
| querypie.resources.limits.cpu | string | `"2000m"` | More than 2 CPU cores are recommended. |
| querypie.resources.limits.memory | string | `"16Gi"` | More than 16Gi memory is recommended. |
| querypie.resources.requests.cpu | string | `"2000m"` |  |
| querypie.resources.requests.memory | string | `"16Gi"` |  |
| querypie.tolerations | object | `{}` |  |
| querypie.updateStrategy.type | string | `"RollingUpdate"` | The strategy used for updating the QueryPie pods. It is generally recommended to use the RollingUpdate strategy. But if required, you can change it to OnDelete for manual operations. |
| serviceAccount | object | {} | ServiceAccount for QueryPie and QueryPie tools pods It is created for authenticating private image registry and AWS API. |
| serviceAccount.imagePullSecrets | list | `[{"name":"querypie-regcred"}]` | The name of the secret used for pulling the QueryPie image from the private registry. To create, run `kubectl create secret docker-registry querypie-regcred --docker-server=harbor.chequer.io --docker-username=admin --docker-password=your-password` |
| tools.annotations | object | `{}` |  |
| tools.enabled | bool | `true` | Create deployment resources for QueryPie tools. It is used for migrating DB, creating snapshots, and so on. |
| tools.image.registry | string | `nil` | Registry used for the QueryPie tools image. If not set, the global registry will be used. |
| tools.image.repository | string | `"querypie/querypie-tools"` | Repository used for the QueryPie tools image. (required) |
| tools.image.tag | string | `nil` | Tag used for the QueryPie tools image. If not set, the global tag will be used. |
| tools.labels | object | `{}` |  |
| tools.nodeSelector | object | `{}` |  |
| tools.tolerations | object | `{}` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.13.1](https://github.com/norwoodj/helm-docs/releases/v1.13.1)
