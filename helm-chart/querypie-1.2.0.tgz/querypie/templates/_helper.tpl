{{- define "querypie.chart" }}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "querypie.name" -}}
{{- .Chart.Name }}
{{- end }}

{{- define "querypie.fullname" -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "querypie.proxy-service.name" -}}
{{- include "querypie.fullname" . | printf "%s-proxy" }}
{{- end }}

{{- define "querypie.configmap.name" -}}
{{- include "querypie.fullname" . | printf "%s-config" }}
{{- end }}

{{- define "querypie.tools.name" -}}
{{- include "querypie.fullname" . | printf "%s-tools" }}
{{- end }}

{{/* Selector labels */}}
{{- define "querypie.selectorLabels" -}}
app.kubernetes.io/name: {{ include "querypie.name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end }}

{{/* Common labels */}}
{{- define "querypie.labels" -}}
helm.sh/chart: {{ include "querypie.chart" . | quote }}
app.kubernetes.io/version: {{ .Values.appVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
{{ include "querypie.selectorLabels" . }}
{{- with .Values.global.labels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/* Common annotations */}}
{{- define "querypie.annotations" -}}
{{- with .Values.global.annotations }}
{{- toYaml . | nindent 4 }}
{{- end }}
{{- end }}
