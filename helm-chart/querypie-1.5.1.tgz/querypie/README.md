# querypie

![Version: 1.5.1](https://img.shields.io/badge/Version-1.5.1-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 11.5.6](https://img.shields.io/badge/AppVersion-11.5.6-informational?style=flat-square)

A Helm chart for QueryPie

**Homepage:** <https://www.querypie.com/>

## Requirements

Kubernetes: `^1.25.0-0`

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| appVersion | string | `"11.5.6"` |  |
| config.agentless.enabled | bool | `false` | If true, QueryPie will enable the Agentless connection. This will open {startPort}~{endPort}/tcp ports on proxyService LoadBalancer. Be careful when you enable this feature because the LoadBalancer may not support a large number of ports to be opened. |
| config.agentless.endPort | int | `40000` |  |
| config.agentless.startPort | int | `40000` |  |
| config.ai.llmProvider.apiKey | string | `""` | LiteLLM API Key for AI Chat. Community only. |
| config.ai.llmProvider.url | string | `""` | LiteLLM server URL for AI Chat. Community only. |
| config.api.showUserAgentMenu | bool | `false` | If true, show User Agent menu in QueryPie UI |
| config.api.showUserPolicy | bool | `true` | If true, show assigned policy details to normal SAC users |
| config.api.useSetCookieSecure | bool | `false` | Cookie Secure flag setting |
| config.cloudsync.aws.accountID | string | `"123456789012"` | The Account ID of the AWS used for cross-account access. |
| config.cloudsync.aws.enabled | bool | `false` | If true, QueryPie will automatically sync resources in the AWS. |
| config.dac.decryptionWorkflow.cubeoneUrl | string | `""` | CUBE ONE module address |
| config.dac.decryptionWorkflow.enabled | bool | `false` | Decided to provide CUBE ONE decryption workflow type |
| config.dac.defaultDbTableAccessType | string | `"all"` | Default Setting table permissions received through workflow |
| config.dac.disableIndirectPolicy | bool | `false` | Allows columns with masking policies to be used in WHERE conditions. |
| config.dac.disableProxyComment | bool | `false` | Remove comments like /* ApplicationName=QueryPie Proxy */ that are attached when running QueryPie. |
| config.dac.disableValidateConnection | bool | `false` | Disable query transmission for DB connection confirmation. |
| config.dac.drmExportProxyURL | string | `""` | Redirect host for applying DRM when exporting results |
| config.dac.enableAthenaColumnFromTableProperties | bool | `false` | If true, reads Spark-related table properties and changes the column order. Used in Athena. |
| config.dac.enableLiteProxy | bool | `false` | If true, Use lite proxy. |
| config.dac.experimentQsiStaticTableConfigData | string | `"{}"` | This setting is used to config QSI Static Table. Please refer to the commented-out example below. |
| config.dac.experimentQsiStaticTableConfigFile | string | `"/app/engine/qsi_static.json"` | The path where the qsi static config file will be mounted. |
| config.dac.experimentalCommandLimit | int | `-1` | The limit number of queries a user can execute per 1 second. |
| config.dac.fileUploadDefaultLimit | int | `10` | Default value for file upload size limit. |
| config.dac.fileUploadLimit.csv | int | `10` | Upload capacity limits applied to csv file format. Default is fileUploadDefaultLimit. |
| config.dac.fileUploadLimit.excel | int | `10` | Upload capacity limits applied to excel file format. Default is fileUploadDefaultLimit. |
| config.dac.fileUploadLimit.json | int | `10` | Upload capacity limits applied to json file format. Default is fileUploadDefaultLimit. |
| config.dac.fileUploadLimit.sql | int | `10` | Upload capacity limits applied to sql file format. Default is fileUploadDefaultLimit. |
| config.dac.ignoreHttpsServerCertificateErrors | bool | `false` | If true, disable HTTPS certificate verification in proxy |
| config.dac.importTransformUrl | string | `""` | API URL to pre-process files on import |
| config.dac.npgsqlDisablePooling | bool | `false` | Disable Npgsql connection pooling for Postgres / Redshift |
| config.dac.selectAuditSnapshot | object | `{"aws":{"accessKey":"","bucket":"","region":"ap-northeast-2","secretAccessKey":""},"enabled":false}` | Enable storing full select query result snapshots to S3 |
| config.dac.selectAuditSnapshot.aws.accessKey | string | `""` | S3 Access Key for Select Audit Snapshot |
| config.dac.selectAuditSnapshot.aws.bucket | string | `""` | S3 bucket for Select Audit Snapshot |
| config.dac.selectAuditSnapshot.aws.region | string | `"ap-northeast-2"` | S3 region for Select Audit Snapshot |
| config.dac.selectAuditSnapshot.aws.secretAccessKey | string | `""` | S3 Secret Access Key for Select Audit Snapshot |
| config.dac.skipCommandConfigData | string | `"{}"` | This setting is used to ignore simple queries sent by client tools such as DataGrip. Please refer to the commented-out example below. |
| config.dac.skipCommandConfigFile | string | `"/app/arisa/skip_command_config.json"` | The path where the skip command config file will be mounted. |
| config.database.querypie.connectionPoolSize | int | `20` | The maximum number of connections that QueryPie can use for "metastore" purposes. |
| config.database.redis.clientKeyPassword | string | `""` | redis tls client key password |
| config.database.redis.disableResp3 | string | `"false"` | If setting true, force disable the use of RESP3 protocol in Redis |
| config.database.redis.useSSL | bool | `false` | redis tls setting If setting true, run `kubectl create secret generic redis-tls --from-file=redis-ca.crt={ca file} --from-file=redis-client.crt={client cert file} --from-file=redis-client.key={client key file}` |
| config.database.redis.username | string | `""` | redis tls username |
| config.engine.jdbcExtraJvmArgs | string | `""` | Extra JVM args for JDBC.NET Java bridge process |
| config.externalURL | string | `"https://querypie.querypie.io"` | NOTE: This environment variable is deprecated as of version 10.2.8, and it has been replaced by specifying the Web Base URL in the General menu. ~~`External URL that users use to access the QueryPie via web.`~~ Required for migration when upgrading from a version lower than 10.2.8 |
| config.integrations.activeDirectory.certFileList | list | `[]` | List of Active Directory certificate files for ldaps support. If setting, run `kubectl create secret generic ad-cert-files --from-file={cert file 1} --from-file={cert file 2} ...` |
| config.mcp.redis.db | int | `0` | Redis DB number for MAC HA |
| config.mcp.redis.node | string | `""` | Redis node address for MAC HA |
| config.mcp.redis.password | string | `""` | Redis password for MAC HA |
| config.mcp.redis.tls | bool | `false` | Redis TLS setting for MAC HA |
| config.mcp.redis.username | string | `""` | Redis ACL username for MAC HA |
| config.monitoring.otel.collector_endpoint | string | `"http://jaeger:4317"` | Endpoint of the otel collector. |
| config.monitoring.otel.enable | bool | `false` | If true, send otel trace data to otel collector. |
| config.nova.redis.db | int | `0` | NOVAS Redis DB number |
| config.nova.redis.node | string | `""` | NOVAS Redis node address |
| config.nova.redis.useTLS | bool | `false` | NOVAS Redis TLS setting |
| config.nova.redis.username | string | `""` | NOVAS Redis ACL username |
| config.nova.server.token | string | `"e1134c60-d28f-4773-ade8-5001b412f778"` | Token for authentication between externally installed NOVA Client and NOVA Server. |
| config.sac.appm.appmSecretHost | string | `"localhost"` | Appm Secret API host. |
| config.sac.appm.enableAppmSecret | bool | `false` | If true, use Appm Secret. |
| config.sac.serverAgentLatestVersion | string | `"11.2.0"` | The latest rdp server agent version available for download from QueryPie. For rdp server agent auto update. |
| config.secretName | string | `"querypie-secret"` | The secret used for the general QueryPie config. To create, run `kubectl create secret generic querypie-secret --from-env-file=querypie.env` The secret should contain the following ``` AGENT_SECRET: {32 length string} DB_HOST: querypie-db.querypie.com DB_PORT: 3306 DB_USERNAME: querypie DB_PASSWORD: somepassword DB_CATALOG: querypie LOG_DB_HOST: querypie-db.querypie.com LOG_DB_PORT: 3306 LOG_DB_USERNAME: querypie LOG_DB_PASSWORD: somepassword LOG_DB_CATALOG: querypie-log ENG_DB_HOST: querypie-db.querypie.com ENG_DB_PORT: 3306 ENG_DB_USERNAME: querypie ENG_DB_PASSWORD: somepassword ENG_DB_CATALOG: querypie-snapshot KEK: key_encryption_key REDIS_DB: 0 REDIS_PASSWORD: somepassword REDIS_CONNECTION_MODE: STANDALONE or Cluster REDIS_NODES: querypie-redis.querypie.com:6379 In 10.2.2 or higher setting storage db (can be used the same as ENG_DB). STORAGE_DB_HOST: querypie-db.querypie.com STORAGE_DB_PORT: 3306 STORAGE_DB_CATALOG: querypie STORAGE_DB_USER: querypie STORAGE_DB_PASSWORD: somepassword Optional: The secret can contain the following if you want to use the different username and password for DDL operation. DB_TOOLS_USERNAME: qptools DB_TOOLS_PASSWORD: somepassword LOG_DB_TOOLS_USERNAME: qptools LOG_DB_TOOLS_PASSWORD: somepassword ENG_DB_TOOLS_USERNAME: qptools ENG_DB_TOOLS_PASSWORD: somepassword Optional: The secret will contain the following when you use the Reverse Tunnel and QueryPie is built with replication. NOVAS_REDIS_PASSWORD: somepassword NOTE: Set NOVAS_REDIS_NODE with config.nova.redis.node. ``` |
| config.storage.s3.bucket | string | `""` | S3 bucket. |
| config.storage.s3.credential.accessKey | string | `""` | S3 access key. Required if credential type is static. |
| config.storage.s3.credential.secretAccessKey | string | `""` | S3 secret access key. Required if credential type is static. |
| config.storage.s3.credential.sessionToken | string | `""` | S3 session token. Required if credential type is static. |
| config.storage.s3.credential.type | string | `"default"` | S3 Credential Types (default or static). default (recommend) : use default credentials set on the running machine. static : set all credential options |
| config.storage.s3.enable | bool | `false` | If true, use S3 storage. |
| config.storage.s3.endPoint | string | `""` | S3 compatible api url |
| config.storage.s3.mode | string | `"aws"` | aws or minio. |
| config.storage.s3.region | string | `""` | S3 region. Ignore if s3 mode is minio. |
| demo.enabled | bool | `false` | If true, the demo resources, such as MySQL and Redis, will be deployed with PoC configuration. Do not enable this in a production environment. |
| demo.mysql.image | string | `"mysql:8.0"` | The image used for the MySQL database. |
| demo.mysql.resources | object | `{}` |  |
| demo.mysql.rootPassword | string | `"querypie"` | The root password for the MySQL database. |
| demo.mysql.volumeClaimTemplate.spec.accessModes[0] | string | `"ReadWriteOnce"` |  |
| demo.mysql.volumeClaimTemplate.spec.resources.requests.storage | string | `"5Gi"` |  |
| demo.redis.image | string | `"redis:7.4"` | The image used for the Redis database. |
| demo.redis.password | string | `"querypie"` | The password for the Redis database. |
| demo.redis.resources | object | `{}` |  |
| global.image.pullPolicy | string | `"IfNotPresent"` | Default image pull policy for all images |
| global.image.registry | string | `"harbor.chequer.io"` | Default registry used for all images |
| global.image.tag | string | `"11.5.6"` | Default image tags used for all images |
| global.labels | object | `{}` | Default labels for all resources deployed by the chart |
| querypie.annotations | object | `{}` | Annotations used for QueryPie pods. |
| querypie.appService | object | `{"annotations":{},"labels":{}}` | The service used for the QueryPie pods' 80/tcp port. |
| querypie.appService.annotations | object | `{}` | Annotations used for the app service resource. |
| querypie.appService.labels | object | `{}` | Labels used for the app service resource. |
| querypie.externalStorage | object | `{"persistentVolumeClaim":{"claimName":"","metadata":{"annotations":{},"labels":{}},"spec":{"accessModes":["ReadWriteMany"],"resources":{"requests":{"storage":"100Gi"}},"storageClassName":""},"useExisting":false},"type":"none"}` | External storage for the QueryPie Object Storage. |
| querypie.externalStorage.persistentVolumeClaim | object | `{"claimName":"","metadata":{"annotations":{},"labels":{}},"spec":{"accessModes":["ReadWriteMany"],"resources":{"requests":{"storage":"100Gi"}},"storageClassName":""},"useExisting":false}` | Use a persistent volume claim for the external storage. It will be available if the type is persistentVolumeClaim. |
| querypie.externalStorage.persistentVolumeClaim.claimName | string | `""` | The name of the existing Persistent Volume Claim to be used. |
| querypie.externalStorage.persistentVolumeClaim.metadata | object | `{"annotations":{},"labels":{}}` | Metadata of the Persistent Volume Claim. |
| querypie.externalStorage.persistentVolumeClaim.spec | object | `{"accessModes":["ReadWriteMany"],"resources":{"requests":{"storage":"100Gi"}},"storageClassName":""}` | Spec of the Persistent Volume Claim. |
| querypie.externalStorage.persistentVolumeClaim.spec.accessModes | list | `["ReadWriteMany"]` | It is required to have ReadWriteMany access mode on production. |
| querypie.externalStorage.persistentVolumeClaim.useExisting | bool | `false` | Use an existing Persistent Volume Claim for the external storage. If you set this to true, this helm chart will not create a new Persistent Volume Claim. |
| querypie.externalStorage.type | string | `"none"` | Type of the external storage. - none: No external storage. - persistentVolumeClaim: using a single Persistent Volume Claim for all QueryPie pods. |
| querypie.extraEnvs | object | `{}` | Extra environment variables used for the QueryPie pods. This is useful for experimental features, debugging, workaround, and so on. for example: API_JVM_HEAPSIZE: '2g' will set the JVM heap size to 2GB. |
| querypie.extraVolumeMounts | list | `[]` | Extra volumeMounts for QueryPie container. |
| querypie.extraVolumes | list | `[]` | Extra volumes for QueryPie pods. Used for custom nginx config, custom certificates, HBase driver, logrotate config, and so on. |
| querypie.image.pullPolicy | string | `nil` | PullPolicy used for the QueryPie image. If not set, the global pullPolicy will be used. |
| querypie.image.registry | string | `nil` | Registry used for the QueryPie image. If not set, the global registry will be used. |
| querypie.image.repository | string | `"querypie/querypie"` | Repository used for the QueryPie image. (required) |
| querypie.image.tag | string | `nil` | Tag used for the QueryPie image. If not set, the global tag will be used. |
| querypie.ingress.annotations | object | `{}` | Annotations used for the Ingress resource. It is useful when you want to enable controller-specific feature for the Ingress resource. |
| querypie.ingress.enabled | bool | `true` | If true, Ingress resource for QueryPie will be created. |
| querypie.ingress.extraPaths | list | `[]` | Extra paths used for the Ingress resource. It is mostly used for redirecting HTTP to HTTPS if the ingress controller does not support redirect by default. |
| querypie.ingress.host | string | `"querypie.querypie.io"` | Hostname used for the Ingress resource. If not set, every hostname will be accepted. |
| querypie.ingress.ingressClassName | string | `""` | Class used for the Ingress resource. If not set, the default class will be used. |
| querypie.ingress.labels | object | `{}` |  |
| querypie.ingress.tls | list | `[]` | TLS used for the Ingress resource. |
| querypie.labels | object | `{}` | Labels used for QueryPie pods. |
| querypie.logLevel.console | string | `"info"` | Setting console log level (Currently only waappie is supported) |
| querypie.logLevel.file | string | `"debug"` | Setting file log level (Currently only waappie is supported) |
| querypie.nodeSelector | object | `{}` | NodeSelector for QueryPie pods |
| querypie.podDisruptionBudget.enabled | bool | `false` | Pod disruption budget for the QueryPie pods. It is recommended to create a PodDisruptionBudget in a production environment where more than one QueryPie pod is deployed. |
| querypie.podDisruptionBudget.minAvailable | int | `1` | The minimum number of available pods during the disruption. https://kubernetes.io/docs/tasks/run-application/configure-pdb/ |
| querypie.podManagementPolicy | string | `"Parallel"` | PodManagementPolicy for QueryPie pods. OrderedReady is fine for most cases, but Parallel is also good for large-scale deployments. |
| querypie.proxyService.annotations | object | `{}` | Annotations used for the Service resource. It is useful when you want to enable controller-specific feature for the Service resource. |
| querypie.proxyService.enabled | bool | `true` | Create a service resource for QueryPie Agent connections. Basically, it opens 9000/tcp port for the QueryPie Agent, and 40000~/tcp for the Agentless connections. |
| querypie.proxyService.externalTrafficPolicy | string | `"Local"` | Set the externalTrafficPolicy to Local is recommended for auditing the real client IP address. |
| querypie.proxyService.labels | object | `{}` |  |
| querypie.proxyService.loadBalancerClass | string | `""` |  |
| querypie.proxyService.sessionAffinity | string | `"None"` | SessionAffinity is not required for the QueryPie. |
| querypie.proxyService.type | string | `"LoadBalancer"` |  |
| querypie.replicas | int | `1` | Replica count for QueryPie pods. More than 1 is recommended for high availability. |
| querypie.resources.limits.cpu | string | `"2000m"` | More than 2 CPU cores are recommended. |
| querypie.resources.limits.memory | string | `"16Gi"` | More than 16Gi memory is recommended. |
| querypie.resources.requests.cpu | string | `"2000m"` |  |
| querypie.resources.requests.memory | string | `"16Gi"` |  |
| querypie.tolerations | list | `[]` |  |
| querypie.topologySpreadConstraints | list | `[]` | TopologySpreadConstraints for QueryPie pods. |
| querypie.updateStrategy.type | string | `"RollingUpdate"` | The strategy used for updating the QueryPie pods. It is generally recommended to use the RollingUpdate strategy. But if required, you can change it to OnDelete for manual operations. |
| serviceAccount | object | {} | ServiceAccount for QueryPie and QueryPie tools pods It is created for authenticating private image registry and AWS API. |
| serviceAccount.imagePullSecrets | list | `[{"name":"querypie-regcred"}]` | The name of the secret used for pulling the QueryPie image from the private registry. To create, run `kubectl create secret docker-registry querypie-regcred --docker-server=harbor.chequer.io --docker-username=admin --docker-password=your-password` |
| tools.annotations | object | `{}` |  |
| tools.enabled | bool | `true` | Create deployment resources for QueryPie tools. It is used for migrating DB, creating snapshots, and so on. |
| tools.image.registry | string | `nil` | Registry used for the QueryPie tools image. If not set, the global registry will be used. |
| tools.image.repository | string | `"querypie/querypie-tools"` | Repository used for the QueryPie tools image. (required) |
| tools.image.tag | string | `nil` | Tag used for the QueryPie tools image. If not set, the global tag will be used. |
| tools.labels | object | `{}` |  |
| tools.nodeSelector | object | `{}` |  |
| tools.tolerations | list | `[]` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
